 Use Python3 for Data fetching and processing(except for G15/CODE/preprocess_fetch_data/fetchwikiArticles.py  ), use python2 for this instead.

Procedure to fetch Data and process it

1. G15/DAT/mids.txt consists of line separated mids( Freebase Id's) of entities.

2. To fetch entities present in this file , run G15/CODE/preprocess_fetch_data/fetch_freebase_triples.py  
   This requires proxy settings to be modified.
   Inside "G15/CODE/preprocess_fetch_data/fetch_freebase_triples.py" modify "http_proxy=http://USER:PASSWORD@PROXYIP:PORT" ,"https_proxy=https://USER:PASSWORD@PROXYIP:PORT","ftp_proxy=ftp://USER:PASSWORD@PROXYIP:PORT" to your details


   G15/DATA/freebase_entity/ will contain raw entity corresponding to Id in G15/DATA/mids.txt .
   G15/DATA/freebase_entity_processed/ will contain processed entity corresponding to Id in G15/DATA/mids.txt.

3. Get wiki Links of all the entities , run G15/CODE/preprocess_fetch_data/extract_wiki_links_from_entities.py  
4. Get raw wiki of all the entities ,run G15/CODE/preprocess_fetch_data/fetchwikiArticles.py  -- use python2 for this
5. Process wikipedia articles of all the entities , run G15/CODE/preprocess_fetch_data/process_wiki_files.py

 
Result: 
1.All entities are present in G15/DATA/freebase_entity/.
2.Entities with their facts are present in G15/DATA/freebase_entity_processed/.
3.The processed wikipedia articles for the entities with freebase Id's in mids.txt have been stored in G15/DATA/wikiDataParsedText/ . Each file name is the entity name.  
4. To check for more entities insert freebase person/person/ mids in mids.txt in line separated format and run all the above 5 steps again.


